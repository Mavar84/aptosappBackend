from routes import apartamentos, inquilinos, contratos, pagos, devoluciones, fotos
